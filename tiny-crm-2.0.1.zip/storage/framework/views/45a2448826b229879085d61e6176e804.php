<div>
    <?php echo e($this->getTranslationPreview($getRecord(), 50)); ?>

</div><?php /**PATH C:\xampp\htdocs\tiny-crm-2.0.1\vendor\kenepa\translation-manager\src\/../resources/views/preview-column.blade.php ENDPATH**/ ?>