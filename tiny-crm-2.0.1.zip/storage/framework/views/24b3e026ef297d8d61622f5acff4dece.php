<div
    <?php echo e($attributes
            ->merge([
                'id' => $getId(),
            ], escape: false)
            ->merge($getExtraAttributes(), escape: false)); ?>

>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH C:\xampp\htdocs\tiny-crm-2.0.1\vendor\filament\forms\src\/../resources/views/components/grid.blade.php ENDPATH**/ ?>