<?php
if(!function_exists('try_svg')) {
    function try_svg($name, $classes) {
        try {
            return svg($name, $classes);
        }
        catch(\Exception $e) {
            return '❓';
        }
    }
}
?>

<div x-data="{
        toggle: function (event) {
            $refs.panel.toggle(event)
        },
        open: function (event) {
            $refs.panel.open(event)
        },
        close: function (event) {
            $refs.panel.close(event)
        },
    }">

    <button
        class="<?php echo \Illuminate\Support\Arr::toCssClasses([
            'ml-4 block hover:opacity-75',
            'pt-0' => $showFlags,
        ]); ?>"
        id="filament-language-switcher"
        x-on:click="toggle"
    >
        <div
            class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                'flex items-center justify-center rounded-full bg-cover bg-center',
                'w-10 h-10 bg-gray-200 dark:bg-gray-900' => $showFlags,
                'w-[2.3rem] h-[2.3rem] bg-[#030712]' => !$showFlags,
            ]); ?>"
        >
            <span class="opacity-100">
                <?php if($showFlags): ?>
                    <?php echo e(try_svg('flag-1x1-'.$currentLanguage['flag'], 'rounded-full w-10 h-10')); ?>

                <?php else: ?>
                    <?php if (isset($component)) { $__componentOriginal606b6d7eddc2e418f11096356be15e19 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal606b6d7eddc2e418f11096356be15e19 = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Icon::resolve(['name' => 'heroicon-o-language'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Icon::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal606b6d7eddc2e418f11096356be15e19)): ?>
<?php $attributes = $__attributesOriginal606b6d7eddc2e418f11096356be15e19; ?>
<?php unset($__attributesOriginal606b6d7eddc2e418f11096356be15e19); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal606b6d7eddc2e418f11096356be15e19)): ?>
<?php $component = $__componentOriginal606b6d7eddc2e418f11096356be15e19; ?>
<?php unset($__componentOriginal606b6d7eddc2e418f11096356be15e19); ?>
<?php endif; ?>
                <?php endif; ?>
            </span>
        </div>
    </button>

    <div x-ref="panel" x-float.placement.bottom-end.flip.offset="{ offset: 8 }" x-transition:enter-start="opacity-0 scale-95" x-transition:leave-end="opacity-0 scale-95" class="ffi-dropdown-panel absolute z-10 w-screen divide-y divide-gray-100 rounded-lg bg-white shadow-lg ring-1 ring-gray-950/5 transition dark:divide-white/5 dark:bg-gray-900 dark:ring-white/10 max-w-[14rem]" style="display: none; left: 1152px; top: 59.5px;">
        <div class="filament-dropdown-list p-1">
            <?php $__currentLoopData = $otherLanguages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $isCurrent = $currentLanguage['code'] === $language['code']; ?>
                <a
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'filament-dropdown-list-item filament-dropdown-item group flex w-full items-center whitespace-nowrap rounded-md p-2 text-sm outline-none text-gray-500 dark:text-gray-200',
                        'hover:bg-gray-50 focus:bg-gray-50 dark:hover:bg-white/5 dark:focus:bg-white/5 hover:text-gray-700 focus:text-gray-500 dark:hover:text-gray-200 dark:focus:text-gray-400' => !$isCurrent,
                        'cursor-default' => $isCurrent,
                    ]); ?>"
                    <?php if(!$isCurrent): ?>
                        href="<?php echo e(route('translation-manager.switch', ['code' => $language['code']])); ?>"
                    <?php endif; ?>
                >
                    <span class="filament-dropdown-list-item-label truncate w-full text-start flex justify-content-start gap-3">
                        <?php if($showFlags): ?>
                            <?php echo e(try_svg('flag-4x3-'.$language['flag'], 'w-6 h-6')); ?>


                            <span class="pl"><?php echo e($language['name']); ?></span>
                        <?php else: ?>
                            <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold' => $isCurrent]); ?>"><?php echo e(str($language['code'])->upper()->value() . " - {$language['name']}"); ?></span>
                        <?php endif; ?>
                    </span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\tiny-crm-2.0.1\vendor\kenepa\translation-manager\src\/../resources/views/language-switcher.blade.php ENDPATH**/ ?>