<?php

namespace App\Enums;

enum ProductType: int
{
    case Service = 1;
    case Physical = 2;
}